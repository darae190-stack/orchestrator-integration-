"""Tests for the Orchestrator client. No network access required."""

from __future__ import annotations

import pytest
from anthropic import APIStatusError as AnthropicStatusError
from anthropic.types import Message
from openai import APIStatusError as OpenAIStatusError
from openai.types import Model as OpenAIModel
from openai.types.chat import ChatCompletion

from orchestrator import (
    AuthError,
    BadRequestError,
    MissingApiKeyError,
    PerplexityOrchestrator,
    RateLimitedError,
    TierExcludedError,
    chat_text,
    message_text,
)
from orchestrator import client as client_module


class FakeResponse:
    """Minimal stand-in for an httpx.Response carrying status and headers."""

    def __init__(self, status_code: int, headers: dict[str, str] | None = None) -> None:
        self.status_code = status_code
        self.headers = headers or {}
        self.request = None


@pytest.fixture
def api_key(monkeypatch: pytest.MonkeyPatch) -> str:
    monkeypatch.setenv("PERPLEXITY_API_KEY", "test-key")
    return "test-key"


def make_chat_completion() -> ChatCompletion:
    return ChatCompletion.model_validate(
        {
            "id": "chatcmpl-1",
            "object": "chat.completion",
            "created": 1,
            "model": "perplexity/kimi-k3",
            "choices": [
                {
                    "index": 0,
                    "finish_reason": "stop",
                    "message": {"role": "assistant", "content": "hi there"},
                }
            ],
            "usage": {"prompt_tokens": 3, "completion_tokens": 2, "total_tokens": 5},
        }
    )


def make_message() -> Message:
    return Message.model_validate(
        {
            "id": "msg_1",
            "type": "message",
            "role": "assistant",
            "model": "perplexity/kimi-k3",
            "content": [{"type": "text", "text": "hi there"}],
            "stop_reason": "end_turn",
            "stop_sequence": None,
            "usage": {"input_tokens": 1, "output_tokens": 2},
        }
    )


def status_error(
    status_code: int, headers: dict[str, str] | None = None, *, anthropic: bool = False
) -> OpenAIStatusError | AnthropicStatusError:
    response = FakeResponse(status_code, headers)
    if anthropic:
        return AnthropicStatusError("boom", response=response, body=None)
    return OpenAIStatusError("boom", response=response, body=None)


def test_missing_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("PERPLEXITY_API_KEY", raising=False)
    with pytest.raises(MissingApiKeyError, match="console.perplexity.ai"):
        PerplexityOrchestrator()


def test_base_urls(api_key: str) -> None:
    orch = PerplexityOrchestrator()
    assert str(orch._openai.base_url).rstrip("/") == "https://api.perplexity.ai/orchestrator/v1"
    assert str(orch._anthropic.base_url).rstrip("/") == "https://api.perplexity.ai/orchestrator"


def test_models_lists_catalog(api_key: str, monkeypatch: pytest.MonkeyPatch) -> None:
    orch = PerplexityOrchestrator()
    models = [
        OpenAIModel.model_validate(
            {"id": "perplexity/kimi-k3", "object": "model", "created": 1, "owned_by": "pplx"}
        ),
        OpenAIModel.model_validate(
            {
                "id": "anthropic/claude-sonnet-5",
                "object": "model",
                "created": 1,
                "owned_by": "pplx",
            }
        ),
    ]
    monkeypatch.setattr(orch._openai.models, "list", lambda: iter(models))
    assert orch.models() == ["anthropic/claude-sonnet-5", "perplexity/kimi-k3"]


def test_chat_sends_openai_schema(api_key: str, monkeypatch: pytest.MonkeyPatch) -> None:
    orch = PerplexityOrchestrator()
    captured: dict = {}

    def fake_create(**kwargs: object) -> ChatCompletion:
        captured.update(kwargs)
        return make_chat_completion()

    monkeypatch.setattr(orch._openai.chat.completions, "create", fake_create)
    response = orch.chat(
        model="perplexity/kimi-k3",
        messages=[{"role": "user", "content": "hello"}],
    )
    assert chat_text(response) == "hi there"
    assert captured["model"] == "perplexity/kimi-k3"
    assert captured["max_completion_tokens"] == 1024
    assert captured["messages"] == [{"role": "user", "content": "hello"}]


def test_chat_stream_sets_stream_and_usage(api_key: str, monkeypatch: pytest.MonkeyPatch) -> None:
    orch = PerplexityOrchestrator()
    captured: dict = {}

    def fake_create(**kwargs: object) -> list[None]:
        captured.update(kwargs)
        return iter([])

    monkeypatch.setattr(orch._openai.chat.completions, "create", fake_create)
    list(orch.chat_stream(model="perplexity/kimi-k3", messages=[{"role": "user", "content": "hi"}]))
    assert captured["stream"] is True
    assert captured["stream_options"] == {"include_usage": True}


def test_message_sends_anthropic_schema(api_key: str, monkeypatch: pytest.MonkeyPatch) -> None:
    orch = PerplexityOrchestrator()
    captured: dict = {}

    def fake_create(**kwargs: object) -> Message:
        captured.update(kwargs)
        return make_message()

    monkeypatch.setattr(orch._anthropic.messages, "create", fake_create)
    message = orch.message(
        model="perplexity/kimi-k3",
        system="be brief",
        messages=[{"role": "user", "content": "hello"}],
    )
    assert message_text(message) == "hi there"
    assert captured["model"] == "perplexity/kimi-k3"
    assert captured["max_tokens"] == 1024
    assert captured["system"] == "be brief"


def test_message_stream_sets_stream(api_key: str, monkeypatch: pytest.MonkeyPatch) -> None:
    orch = PerplexityOrchestrator()
    captured: dict = {}

    def fake_create(**kwargs: object) -> list[None]:
        captured.update(kwargs)
        return iter([])

    monkeypatch.setattr(orch._anthropic.messages, "create", fake_create)
    stream = orch.message_stream(
        model="perplexity/kimi-k3", messages=[{"role": "user", "content": "hi"}]
    )
    list(stream)
    assert captured["stream"] is True


def test_429_retries_honoring_retry_after(
    api_key: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    orch = PerplexityOrchestrator()
    calls: list[int] = []
    sleeps: list[float] = []

    def fake_create(**kwargs: object) -> ChatCompletion:
        calls.append(1)
        if len(calls) == 1:
            raise status_error(429, {"Retry-After": "3"})
        return make_chat_completion()

    monkeypatch.setattr(orch._openai.chat.completions, "create", fake_create)
    monkeypatch.setattr(client_module.time, "sleep", sleeps.append)
    response = orch.chat(model="perplexity/kimi-k3", messages=[{"role": "user", "content": "hi"}])
    assert chat_text(response) == "hi there"
    assert len(calls) == 2
    assert sleeps == [3.0]


def test_429_exhausted_retries_raises(api_key: str, monkeypatch: pytest.MonkeyPatch) -> None:
    orch = PerplexityOrchestrator(max_retries=1)
    sleeps: list[float] = []

    def fake_create(**kwargs: object) -> ChatCompletion:
        raise status_error(429, {"Retry-After": "2"})

    monkeypatch.setattr(orch._openai.chat.completions, "create", fake_create)
    monkeypatch.setattr(client_module.time, "sleep", sleeps.append)
    with pytest.raises(RateLimitedError) as excinfo:
        orch.chat(model="perplexity/kimi-k3", messages=[{"role": "user", "content": "hi"}])
    assert excinfo.value.retry_after == 2.0
    assert sleeps == [2.0]


def test_401_translated_to_auth_error(api_key: str, monkeypatch: pytest.MonkeyPatch) -> None:
    orch = PerplexityOrchestrator()

    def fake_create(**kwargs: object) -> ChatCompletion:
        raise status_error(401)

    monkeypatch.setattr(orch._openai.chat.completions, "create", fake_create)
    with pytest.raises(AuthError, match="rotate"):
        orch.chat(model="perplexity/kimi-k3", messages=[{"role": "user", "content": "hi"}])


def test_402_translated_to_tier_error(api_key: str, monkeypatch: pytest.MonkeyPatch) -> None:
    orch = PerplexityOrchestrator()

    def fake_create(**kwargs: object) -> ChatCompletion:
        raise status_error(402)

    monkeypatch.setattr(orch._openai.chat.completions, "create", fake_create)
    with pytest.raises(TierExcludedError, match="usage tier"):
        orch.chat(model="perplexity/kimi-k3", messages=[{"role": "user", "content": "hi"}])


def test_400_translated_to_bad_request(api_key: str, monkeypatch: pytest.MonkeyPatch) -> None:
    orch = PerplexityOrchestrator()

    def fake_create(**kwargs: object) -> ChatCompletion:
        raise status_error(400)

    monkeypatch.setattr(orch._openai.chat.completions, "create", fake_create)
    with pytest.raises(BadRequestError, match="catalog"):
        orch.chat(model="not-a-real-slug", messages=[{"role": "user", "content": "hi"}])


def test_anthropic_errors_translated(api_key: str, monkeypatch: pytest.MonkeyPatch) -> None:
    orch = PerplexityOrchestrator()

    def fake_create(**kwargs: object) -> Message:
        raise status_error(429, {"Retry-After": "7"}, anthropic=True)

    monkeypatch.setattr(orch._anthropic.messages, "create", fake_create)
    with pytest.raises(RateLimitedError) as excinfo:
        orch.message(model="perplexity/kimi-k3", messages=[{"role": "user", "content": "hi"}])
    assert excinfo.value.retry_after == 7.0


def test_negative_max_retries_rejected(api_key: str) -> None:
    with pytest.raises(ValueError, match="non-negative integer"):
        PerplexityOrchestrator(max_retries=-1)


def test_boolean_max_retries_rejected(api_key: str) -> None:
    with pytest.raises(ValueError, match="non-negative integer"):
        PerplexityOrchestrator(max_retries=True)


def test_chat_rejects_wrapper_parameter_override(api_key: str) -> None:
    orch = PerplexityOrchestrator()
    with pytest.raises(TypeError, match="max_completion_tokens"):
        orch.chat(
            model="perplexity/kimi-k3",
            messages=[{"role": "user", "content": "hi"}],
            max_completion_tokens=20,
        )


def test_chat_stream_rejects_stream_override(api_key: str) -> None:
    orch = PerplexityOrchestrator()
    with pytest.raises(TypeError, match="stream"):
        orch.chat_stream(
            model="perplexity/kimi-k3",
            messages=[{"role": "user", "content": "hi"}],
            stream=False,
        )
