# Perplexity Orchestrator API Integration

Routes LLM calls through the [Perplexity Orchestrator API](https://docs.perplexity.ai/docs/gateway/quickstart) so frontier models from Anthropic, OpenAI, Google, xAI, and Perplexity can be swapped by changing only the model id — never the provider or SDK.

The Orchestrator API is used with the official OpenAI and Anthropic SDKs pointed at Perplexity base URLs (not the Perplexity SDK):

| Schema | SDK | Base URL | Endpoint |
|---|---|---|---|
| OpenAI Chat Completions | `openai` | `https://api.perplexity.ai/orchestrator/v1` | `POST /chat/completions` |
| Anthropic Messages | `anthropic` | `https://api.perplexity.ai/orchestrator` (the SDK appends `/v1/messages`) | `POST /messages` |

Both schemas accept every model in your key's catalog; model ids are `creator/model-name` slugs such as `anthropic/claude-sonnet-5` or `openai/gpt-5.6-terra`.

## Setup

```bash
python3 -m venv .venv
.venv/bin/pip install -e ".[dev]"
```

Create an API key in the [API Console](https://console.perplexity.ai) and export it in your own terminal (never hardcode, log, or commit it):

```bash
export PERPLEXITY_API_KEY="your-key"
```

## Usage

```python
from orchestrator import PerplexityOrchestrator, chat_text

orch = PerplexityOrchestrator()  # reads PERPLEXITY_API_KEY

orch.models()  # this key's tier-aware catalog and allowlist

# OpenAI Chat Completions schema — swap models by id only
response = orch.chat(
    model="anthropic/claude-sonnet-5",
    messages=[{"role": "user", "content": "Explain the CAP theorem in two sentences."}],
)
print(chat_text(response))
print(response.usage.prompt_tokens, response.usage.completion_tokens)

# Anthropic Messages schema — same catalog, same key
message = orch.message(
    model="openai/gpt-5.6-terra",
    system="be brief",
    messages=[{"role": "user", "content": "hello"}],
)
```

Streaming: `orch.chat_stream(...)` (set `stream: true`; usage arrives in a final chunk via `stream_options.include_usage`) and `orch.message_stream(...)` (typed events from `message_start` through `message_stop`).

## Error Handling

HTTP errors are translated to typed exceptions; 429 responses are retried (by default twice) honoring the `Retry-After` header, which for the Orchestrator API can also mean temporary model overload.

| Exception | HTTP | Meaning |
|---|---|---|
| `MissingApiKeyError` | — | `PERPLEXITY_API_KEY` not set in the environment |
| `AuthError` | 401/403 | bad or revoked key — check/rotate at the console |
| `BadRequestError` | 400 | invalid request; if it names the model, the slug is not in your catalog |
| `TierExcludedError` | 402 | model excluded for your organization's usage tier |
| `RateLimitedError` | 429 | rate limited or model overloaded; `.retry_after` holds the header value |

Failures before the first token are retried across deployments automatically by Perplexity; if every deployment fails you get a 429 with `Retry-After`. Treat unterminated streams as incomplete (see [routing and reliability](https://docs.perplexity.ai/docs/gateway/routing-and-reliability)).

## Verification

```bash
.venv/bin/python smoke_test.py        # live 200-expected smoke test (prints status/shape only)
.venv/bin/ruff check .               # lint
.venv/bin/mypy                        # type check
.venv/bin/pytest                      # tests (offline)
.venv/bin/python examples/chat_completions.py
```

## Docs

- [Quickstart](https://docs.perplexity.ai/docs/gateway/quickstart)
- [Models & pricing](https://docs.perplexity.ai/docs/gateway/models)
- [Routing & reliability](https://docs.perplexity.ai/docs/gateway/routing-and-reliability)
- [Chat Completions reference](https://docs.perplexity.ai/api-reference/gateway-chat-completions-post)
- [Messages reference](https://docs.perplexity.ai/api-reference/gateway-messages-post)
- [Pricing](https://docs.perplexity.ai/docs/getting-started/pricing)


## Working from an iPhone

This package is Python code and is not an iOS-native app. The practical iPhone workflow is to use a browser-based development environment (for example, GitHub Codespaces in Safari) and run the project in its remote Linux container. Keep `PERPLEXITY_API_KEY` in the environment's secret store; do not put it in source files, screenshots, or a committed `.env` file.

After opening the project in a Python 3.10+ environment, run:

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install -e ".[dev]"
python -m pytest
ruff check .
mypy
```

Only run `python smoke_test.py` after adding your API key as an environment secret. That command makes live API requests and may incur usage charges.
