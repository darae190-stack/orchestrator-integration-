"""Perplexity Orchestrator API integration.

Routes LLM calls through https://api.perplexity.ai/orchestrator so frontier
models can be swapped without changing providers.
"""

from orchestrator.client import (
    CHAT_COMPLETIONS_BASE_URL,
    MESSAGES_BASE_URL,
    AuthError,
    BadRequestError,
    MissingApiKeyError,
    OrchestratorError,
    PerplexityOrchestrator,
    RateLimitedError,
    TierExcludedError,
    chat_text,
    message_text,
)

__all__ = [
    "CHAT_COMPLETIONS_BASE_URL",
    "MESSAGES_BASE_URL",
    "AuthError",
    "BadRequestError",
    "MissingApiKeyError",
    "OrchestratorError",
    "PerplexityOrchestrator",
    "RateLimitedError",
    "TierExcludedError",
    "chat_text",
    "message_text",
]
__version__ = "0.1.0"
