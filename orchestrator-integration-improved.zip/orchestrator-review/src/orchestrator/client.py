"""Client for the Perplexity Orchestrator API.

The Orchestrator API (https://docs.perplexity.ai/docs/gateway/quickstart) provides
direct access to frontier models from Anthropic, OpenAI, Google, xAI, and Perplexity
through OpenAI- and Anthropic-compatible schemas. It is used with the official
OpenAI / Anthropic SDKs pointed at a Perplexity base URL — not with the Perplexity
SDK — and it has no web grounding.

Model ids are ``creator/model-name`` slugs (e.g. ``anthropic/claude-sonnet-5``).
The catalog returned by ``GET /orchestrator/v1/models`` is tier-aware: it is both
the catalog and the allowlist for the API key in use. Never hardcode an unlisted
slug — unlisted models fail with 400, and a model excluded for the organization's
usage tier fails with 402.

Reliability notes (https://docs.perplexity.ai/docs/gateway/routing-and-reliability):
routing, health monitoring, and failover across deployments happen automatically.
A 429 means rate limiting or temporary model overload and carries a ``Retry-After``
header; this client honors it. Deterministic client errors (400/401/402) are not
retried.
"""

from __future__ import annotations

import os
import time
from collections.abc import Callable, Iterable, Iterator
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Any, TypeVar

from anthropic import Anthropic
from anthropic import APIStatusError as AnthropicStatusError
from anthropic.types import Message, MessageParam, RawMessageStreamEvent, TextBlock
from openai import APIStatusError as OpenAIStatusError
from openai import OpenAI
from openai.types.chat import (
    ChatCompletion,
    ChatCompletionChunk,
    ChatCompletionMessageParam,
    ChatCompletionStreamOptionsParam,
)

T = TypeVar("T")

CHAT_COMPLETIONS_BASE_URL = "https://api.perplexity.ai/orchestrator/v1"
MESSAGES_BASE_URL = "https://api.perplexity.ai/orchestrator"  # the SDK appends /v1/messages

CONSOLE_URL = "https://console.perplexity.ai"
DEFAULT_MAX_RETRIES = 2
_BACKOFF_BASE_SECONDS = 2.0


class OrchestratorError(Exception):
    """Base class for Orchestrator API errors raised by this client."""


class MissingApiKeyError(OrchestratorError):
    """PERPLEXITY_API_KEY is not set in the environment."""


class AuthError(OrchestratorError):
    """HTTP 401/403: authentication failed (bad or revoked API key)."""


class TierExcludedError(OrchestratorError):
    """HTTP 402: the model is excluded for the organization's usage tier."""


class BadRequestError(OrchestratorError):
    """HTTP 400: invalid request, e.g. a model slug not in the key's catalog."""


class RateLimitedError(OrchestratorError):
    """HTTP 429: rate limited or model temporarily overloaded, after retries.

    Attributes:
        retry_after: Seconds indicated by the Retry-After header, if any.
    """

    def __init__(self, message: str, *, retry_after: float | None = None) -> None:
        super().__init__(message)
        self.retry_after = retry_after


def _require_api_key() -> str:
    api_key = os.environ.get("PERPLEXITY_API_KEY")
    if not api_key:
        raise MissingApiKeyError(
            "PERPLEXITY_API_KEY is not set. Create an API key at "
            f"{CONSOLE_URL} and export it in your terminal:\n"
            '  export PERPLEXITY_API_KEY="your-key"'
        )
    return api_key


def _retry_after_seconds(headers: Any) -> float | None:
    """Parse a Retry-After header (delay-seconds or HTTP-date) into seconds."""
    value = headers.get("Retry-After")
    if value is None:
        return None
    value = value.strip()
    try:
        return max(0.0, float(value))
    except ValueError:
        try:
            when = parsedate_to_datetime(value)
        except (TypeError, ValueError):
            return None
        if when is None:
            return None
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
        return max(0.0, (when - datetime.now(timezone.utc)).total_seconds())


def _translate_status_error(exc: OpenAIStatusError | AnthropicStatusError) -> OrchestratorError:
    status = exc.response.status_code
    detail = str(exc).strip()
    if status in (401, 403):
        return AuthError(
            f"HTTP {status}: authentication failed. Check that PERPLEXITY_API_KEY is a "
            f"valid key from {CONSOLE_URL} (rotate it there if it may have been "
            f"exposed). Details: {detail}"
        )
    if status == 402:
        return TierExcludedError(
            "HTTP 402: this model is excluded for your organization's usage tier. "
            "Pick a model from your key's catalog via GET /orchestrator/v1/models "
            f"(models() on this client). Details: {detail}"
        )
    if status == 400:
        return BadRequestError(
            "HTTP 400: invalid request. If the error names the model, the slug is not "
            "in your key's catalog — list valid ids with models(). Details: "
            f"{detail}"
        )
    if status == 429:
        retry_after = _retry_after_seconds(exc.response.headers)
        suffix = f"; Retry-After: {retry_after:.0f}s" if retry_after is not None else ""
        return RateLimitedError(
            f"HTTP 429: rate limited or model temporarily overloaded{suffix}. "
            f"Details: {detail}",
            retry_after=retry_after,
        )
    return OrchestratorError(f"HTTP {status}: {detail}")


class PerplexityOrchestrator:
    """Routes LLM calls through the Perplexity Orchestrator API.

    Two schemas, one API key, one catalog of ``creator/model-name`` slugs:

    - ``chat()`` / ``chat_stream()`` — OpenAI Chat Completions schema via the
      OpenAI SDK (base URL ``https://api.perplexity.ai/orchestrator/v1``).
    - ``message()`` / ``message_stream()`` — Anthropic Messages schema via the
      Anthropic SDK (base URL ``https://api.perplexity.ai/orchestrator``; the
      SDK appends ``/v1/messages``).

    Swap frontier models (``anthropic/...``, ``openai/...``, ``google/...``,
    ``xai/...``, ``perplexity/...``) by changing only the model id. Both
    schemas accept every model in the key's catalog.

    The API key is read from the PERPLEXITY_API_KEY environment variable and is
    never logged or printed.
    """

    def __init__(
        self, api_key: str | None = None, *, max_retries: int = DEFAULT_MAX_RETRIES
    ) -> None:
        if isinstance(max_retries, bool) or not isinstance(max_retries, int) or max_retries < 0:
            raise ValueError("max_retries must be a non-negative integer")
        key = api_key if api_key is not None else _require_api_key()
        if not key.strip():
            raise ValueError("api_key must be a non-empty string")
        self._max_retries = max_retries
        # SDK-level retries stay off so that 429 Retry-After handling is ours.
        self._openai = OpenAI(api_key=key, base_url=CHAT_COMPLETIONS_BASE_URL, max_retries=0)
        self._anthropic = Anthropic(api_key=key, base_url=MESSAGES_BASE_URL, max_retries=0)

    def _call(self, fn: Callable[..., T], /, *args: Any, **kwargs: Any) -> T:
        """Invoke an SDK call, retrying 429s per Retry-After.

        For streaming calls the HTTP request is issued when the SDK call runs, so
        an initial 429 surfaces here and is retried. Failures after a stream has
        started are not retried: treat an unterminated stream as incomplete.
        """
        for attempt in range(self._max_retries + 1):
            try:
                return fn(*args, **kwargs)
            except (OpenAIStatusError, AnthropicStatusError) as exc:
                error = _translate_status_error(exc)
                if not isinstance(error, RateLimitedError) or attempt >= self._max_retries:
                    raise error from exc
                delay = (
                    error.retry_after
                    if error.retry_after is not None
                    else _BACKOFF_BASE_SECONDS**attempt
                )
                time.sleep(delay)
        raise AssertionError("unreachable")  # pragma: no cover

    def models(self) -> list[str]:
        """List model ids from GET /orchestrator/v1/models.

        The response is tier-aware: it is both this key's catalog and its
        allowlist. Use these ids for chat()/message().
        """
        # The SDK page object is iterable and transparently fetches subsequent pages.
        # Reading only ``page.data`` silently truncates large catalogs.
        page = self._call(self._openai.models.list)
        return sorted(model.id for model in page)

    def chat(
        self,
        *,
        model: str,
        messages: Iterable[ChatCompletionMessageParam],
        max_tokens: int = 1024,
        **kwargs: Any,
    ) -> ChatCompletion:
        """POST /orchestrator/v1/chat/completions — OpenAI schema.

        Returns a response with exactly one entry in ``choices``. Token usage is
        on ``response.usage`` (``prompt_tokens`` including cache reads/writes,
        ``prompt_tokens_details.cached_tokens``, ``completion_tokens`` including
        reasoning tokens).
        """
        _reject_reserved_kwargs(
            kwargs, {"model", "messages", "max_completion_tokens", "max_tokens"}
        )
        return self._call(
            self._openai.chat.completions.create,
            model=model,
            messages=list(messages),
            max_completion_tokens=max_tokens,
            **kwargs,
        )

    def chat_stream(
        self,
        *,
        model: str,
        messages: Iterable[ChatCompletionMessageParam],
        max_tokens: int = 1024,
        include_usage: bool = True,
        **kwargs: Any,
    ) -> Iterator[ChatCompletionChunk]:
        """Streamed Chat Completions (``stream: true``).

        With ``include_usage=True`` (the default), usage arrives in a final
        chunk before ``data: [DONE]``.
        """
        _reject_reserved_kwargs(
            kwargs,
            {
                "model",
                "messages",
                "max_completion_tokens",
                "max_tokens",
                "stream",
                "stream_options",
            },
        )
        stream_options: ChatCompletionStreamOptionsParam | None = (
            ChatCompletionStreamOptionsParam(include_usage=include_usage) if include_usage else None
        )
        return self._call(
            self._openai.chat.completions.create,
            model=model,
            messages=list(messages),
            max_completion_tokens=max_tokens,
            stream=True,
            stream_options=stream_options,
            **kwargs,
        )

    def message(
        self,
        *,
        model: str,
        messages: Iterable[MessageParam],
        max_tokens: int = 1024,
        system: str | None = None,
        **kwargs: Any,
    ) -> Message:
        """POST /orchestrator/v1/messages — Anthropic Messages schema.

        Returns ``content`` blocks (no ``choices`` field). Token usage is on
        ``message.usage`` (``input_tokens``, ``output_tokens``,
        ``cache_creation_input_tokens``, ``cache_read_input_tokens``).
        """
        _reject_reserved_kwargs(kwargs, {"model", "messages", "max_tokens", "system"})
        params: dict[str, Any] = {
            "model": model,
            "messages": list(messages),
            "max_tokens": max_tokens,
            **kwargs,
        }
        if system is not None:
            params["system"] = system
        return self._call(self._anthropic.messages.create, **params)

    def message_stream(
        self,
        *,
        model: str,
        messages: Iterable[MessageParam],
        max_tokens: int = 1024,
        system: str | None = None,
        **kwargs: Any,
    ) -> Iterator[RawMessageStreamEvent]:
        """Streamed Messages (``stream: true``).

        Emits typed events from ``message_start`` through ``message_stop``.
        """
        _reject_reserved_kwargs(kwargs, {"model", "messages", "max_tokens", "system", "stream"})
        params: dict[str, Any] = {
            "model": model,
            "messages": list(messages),
            "max_tokens": max_tokens,
            "stream": True,
            **kwargs,
        }
        if system is not None:
            params["system"] = system
        return self._call(self._anthropic.messages.create, **params)


def _reject_reserved_kwargs(kwargs: dict[str, Any], reserved: set[str]) -> None:
    """Fail clearly when callers try to override parameters owned by this wrapper."""
    conflicts = sorted(reserved.intersection(kwargs))
    if conflicts:
        names = ", ".join(conflicts)
        raise TypeError(f"These parameters are controlled by this client method: {names}")


def chat_text(response: ChatCompletion) -> str:
    """Assistant text from a Chat Completions response (exactly one choice)."""
    return response.choices[0].message.content or ""


def message_text(message: Message) -> str:
    """Concatenated text blocks from a Messages response."""
    return "".join(
        block.text for block in message.content if isinstance(block, TextBlock)
    )
