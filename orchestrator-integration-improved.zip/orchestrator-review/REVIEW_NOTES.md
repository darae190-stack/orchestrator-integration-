# Source review and changes

## Changes made

1. `PerplexityOrchestrator` now rejects negative, boolean, and non-integer retry counts.
2. An explicitly supplied empty API key is rejected instead of silently falling back to the environment variable.
3. `models()` iterates the SDK page object so SDK pagination can retrieve the complete model catalog rather than only the first page's `.data`.
4. Wrapper-owned request parameters are protected from accidental overrides through `**kwargs`; conflicting names now raise a clear `TypeError`.
5. Added regression tests for retry validation and conflicting request parameters, and updated the model-catalog test to use an iterable page stand-in.
6. Added instructions for developing from an iPhone through a browser-based remote Python environment.

## Verification status

- Python syntax compilation: passed (`python -m compileall`).
- Automated pytest suite: not run to completion because the environment did not have the `anthropic` dependency installed. Installing project dependencies was attempted, but package installation was blocked by unavailable network/DNS access to the package index.
- Live API smoke test: not run; it requires the user's Perplexity API key and makes billable/usage-counted requests.

## Follow-up review items

- Confirm pagination behavior against the exact installed OpenAI SDK version in the user's environment.
- Run `pytest`, `ruff check .`, and `mypy` after installing `.[dev]`.
- Confirm Perplexity's current API behavior and supported model catalog against live documentation before relying on specific model IDs.
