"""Minimal live smoke test for the Perplexity Orchestrator API integration.

Prints only HTTP statuses and response shapes — never the API key.

Usage:
    export PERPLEXITY_API_KEY="your-key"   # create at https://console.perplexity.ai
    python smoke_test.py [model-id]

Expects 200 on every call. 401 means an authentication/key problem; 429 means
rate limiting or temporary model overload (honored via Retry-After in the
client).
"""

from __future__ import annotations

import sys

from orchestrator import MissingApiKeyError, PerplexityOrchestrator


def main() -> None:
    orch = PerplexityOrchestrator()

    # 1. Catalog (also this key's allowlist).
    catalog = orch.models()
    print(f"GET /orchestrator/v1/models: 200 — {len(catalog)} models in this key's catalog")
    print(f"  first ids: {', '.join(catalog[:5])}")

    model = sys.argv[1] if len(sys.argv) > 1 else next(
        (m for m in catalog if "flash" in m), catalog[0]
    )
    print(f"  testing with: {model}")

    # 2. Chat Completions (OpenAI schema).
    response = orch.chat(
        model=model,
        messages=[{"role": "user", "content": "Reply with exactly: ok"}],
        max_tokens=16,
    )
    print(
        f"POST /orchestrator/v1/chat/completions: 200 — "
        f"choices={len(response.choices)} model={response.model} "
        f"usage=({response.usage.prompt_tokens} prompt / "
        f"{response.usage.completion_tokens} completion tokens)"
    )

    # 3. Messages (Anthropic schema).
    message = orch.message(
        model=model,
        messages=[{"role": "user", "content": "Reply with exactly: ok"}],
        max_tokens=16,
    )
    print(
        f"POST /orchestrator/v1/messages: 200 — "
        f"content_blocks={len(message.content)} stop_reason={message.stop_reason} "
        f"usage=({message.usage.input_tokens} input / "
        f"{message.usage.output_tokens} output tokens)"
    )

    print("smoke test passed")


if __name__ == "__main__":
    try:
        main()
    except MissingApiKeyError as error:
        print(f"{type(error).__name__}: {error}", file=sys.stderr)
        sys.exit(2)
