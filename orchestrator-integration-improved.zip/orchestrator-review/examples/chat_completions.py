"""Chat Completions (OpenAI schema) through the Perplexity Orchestrator API.

Usage:
    python examples/chat_completions.py [model-id]

The model id defaults to a model taken from this key's live catalog
(GET /orchestrator/v1/models) — never guess a slug.
"""

from __future__ import annotations

import sys

from orchestrator import PerplexityOrchestrator, chat_text


def main() -> None:
    orch = PerplexityOrchestrator()  # reads PERPLEXITY_API_KEY

    model = sys.argv[1] if len(sys.argv) > 1 else None
    if model is None:
        catalog = orch.models()
        model = next((m for m in catalog if "flash" in m), catalog[0])
        print(f"using model from catalog: {model}")

    response = orch.chat(
        model=model,
        messages=[{"role": "user", "content": "Explain the CAP theorem in two sentences."}],
    )

    # Chat Completions returns exactly one entry in `choices`.
    print(chat_text(response))
    usage = response.usage
    print(
        f"\n[usage: {usage.prompt_tokens} prompt / "
        f"{usage.completion_tokens} completion tokens]"
    )


if __name__ == "__main__":
    main()
