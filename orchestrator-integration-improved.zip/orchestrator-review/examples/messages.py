"""Anthropic Messages schema through the Perplexity Orchestrator API.

Usage:
    python examples/messages.py [model-id]

The Anthropic SDK is configured with base URL https://api.perplexity.ai/orchestrator
(it appends /v1/messages itself). Both Authorization: Bearer and the SDK's
default x-api-key header are accepted.
"""

from __future__ import annotations

import sys

from orchestrator import PerplexityOrchestrator, message_text


def main() -> None:
    orch = PerplexityOrchestrator()  # reads PERPLEXITY_API_KEY

    model = sys.argv[1] if len(sys.argv) > 1 else None
    if model is None:
        catalog = orch.models()
        model = next((m for m in catalog if "flash" in m), catalog[0])
        print(f"using model from catalog: {model}")

    message = orch.message(
        model=model,
        system="Answer in one short sentence.",
        messages=[{"role": "user", "content": "What is prompt caching?"}],
    )

    # Messages returns `content` blocks and no `choices` field.
    print(message_text(message))
    usage = message.usage
    print(f"\n[usage: {usage.input_tokens} input / {usage.output_tokens} output tokens]")


if __name__ == "__main__":
    main()
