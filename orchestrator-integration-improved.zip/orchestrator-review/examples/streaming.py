"""Streaming through the Perplexity Orchestrator API.

Usage:
    python examples/streaming.py [model-id]

- Chat Completions: stream: true with stream_options.include_usage puts token
  usage in a final chunk before data: [DONE].
- Messages: stream: true emits typed events from message_start through
  message_stop.
"""

from __future__ import annotations

import sys

from orchestrator import PerplexityOrchestrator


def main() -> None:
    orch = PerplexityOrchestrator()  # reads PERPLEXITY_API_KEY

    model = sys.argv[1] if len(sys.argv) > 1 else None
    if model is None:
        catalog = orch.models()
        model = next((m for m in catalog if "flash" in m), catalog[0])
        print(f"using model from catalog: {model}")

    print("--- chat_stream (Chat Completions) ---")
    stream = orch.chat_stream(
        model=model,
        messages=[{"role": "user", "content": "Write a haiku about network latency."}],
    )
    for chunk in stream:
        if chunk.choices and chunk.choices[0].delta.content:
            print(chunk.choices[0].delta.content, end="", flush=True)
        if chunk.usage:
            print(f"\n[tokens used: {chunk.usage.total_tokens}]")

    print("\n--- message_stream (Messages) ---")
    events = orch.message_stream(
        model=model,
        messages=[{"role": "user", "content": "Write a haiku about cache misses."}],
    )
    for event in events:
        if event.type == "message_start":
            print(f"message_start: model={event.message.model}")
        elif event.type == "content_block_delta" and event.delta.type == "text_delta":
            print(event.delta.text, end="", flush=True)
        elif event.type == "message_stop":
            print("\nmessage_stop")


if __name__ == "__main__":
    main()
